
#define PROGRAM_VERSION_NUMBER  4, 82, 0, 0
#define PROGRAM_VERSION_TEXT    "4.82.0.0"
#define CURRENT_YEAR            "2017"
#define PROGRAM_COMPANY         "IDS Imaging Development Systems GmbH"


